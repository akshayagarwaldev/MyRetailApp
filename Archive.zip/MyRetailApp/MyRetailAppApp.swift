//
//  MyRetailAppApp.swift
//  MyRetailApp
//
//  Created by aksagarw on 29/08/25.
//

import SwiftUI

@main
struct MyRetailAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
