//
//  MyRetailAppTests.swift
//  MyRetailAppTests
//
//  Created by aksagarw on 29/08/25.
//

import Testing
@testable import MyRetailApp

struct MyRetailAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
